# tecwebapp
The web app for the Tec de Monterrey.

# To install:
1. Create and activate virtual environment
> python -m venv venv

> source venv/bin/activate
> Note: If you use Anaconda: conda activate venv

2. Install dependencies
> pip install -r requirements.txt

# To run the web app
3. Launch development server
> python app.py
